angular.module('ng.capital-planning-details.controller', [])
    .controller('CapitalPlanningDetailsController', ['$scope', '$routeParams', '$location', '$filter', '_', 'CapitalPlanningService', 'VNotificationService', 'ConfirmService',
        function ($scope, $routeParams, $location, $filter, _, CapitalPlanningService, VNotificationService, ConfirmService) {

            $scope.loading = true;
            $scope.Filter = {};
            $scope.Filter.filterSelection = {};
            $scope.Filter.filterOptions = {};
            $scope.rwaTotal = {};


            var dateF = $filter('date');
            var moneyF = $filter('currency');

            var mf = function (val) {
                var t = !isNaN(val) ? _.round(parseFloat(val)/1000000, 2) : 0;
                return moneyF(t, '', 0);
            };

            var fm = function (val) {
                var t = parseFloat1(val);
                return t * 1000000;
            }

            var ppf = function (val) {
                var t = parseFloat1(val);
                return _.round(t * 100, 2);
            };

            var fpp = function (val) {
                var t = parseFloat1(val);
                return t / 100;
            }

            var pf = function (val) {
                var t = parseFloat(val);
                var t1 = !isNaN(t) ? _.round(t * 100, 2) : 0;
                return t1+'%';
            };

            var parseFloat1 = function (val) {
                var t = parseFloat(val);
                return !isNaN(t) ? t : 0;
            }

            var mainFunc = function () {
                var assetClass = ['SOV', 'FI', 'CORP', 'RET', 'NP', 'OTH', 'RE', 'MORT', 'CCR', 'MR', 'OR'];
                $scope.currentCapitalPlanning = CapitalPlanningService.getCurrent();

                var key = $scope.currentCapitalPlanning.capitalKey;
                if (_.isNumber(key.snapShotDate)) {
                    var dt = new Date(key.snapShotDate);
                    var snsd = dt.getFullYear() + '-' + _.padLeft(dt.getMonth()+1, 2, 0) + '-' + dt.getDate();
                    key.snapShotDate = snsd;
                }

                $scope.Filter.filterSelection = key;
                $scope.Filter.filterSelection.snapshotDate=$scope.Filter.filterSelection.snapShotDate;

                //process
                $scope.currentCapitalPlanning.capTier1PctChgDisp = ppf($scope.currentCapitalPlanning.capTier1PctChg);
                $scope.currentCapitalPlanning.capTier2PctChgDisp = ppf($scope.currentCapitalPlanning.capTier2PctChg);
                $scope.currentCapitalPlanning.capTier1ChgAmtDisp = mf($scope.currentCapitalPlanning.capTier1ChgAmt);
                $scope.currentCapitalPlanning.capTier2ChgAmtDisp = mf($scope.currentCapitalPlanning.capTier2ChgAmt);

                $scope.currentCapitalPlanning.weightedAverageChgAmtYear1 =
                    (parseFloat1($scope.currentCapitalPlanning.capTier1ChgAmt) *
                        parseFloat1($scope.currentCapitalPlanning.capTier1ChgYear1) +
                        parseFloat1($scope.currentCapitalPlanning.capTier2ChgAmt) *
                        parseFloat1($scope.currentCapitalPlanning.capTier2ChgYear1)) /
                    (parseFloat1($scope.currentCapitalPlanning.capTier1ChgAmt) + parseFloat1($scope.currentCapitalPlanning.capTier2ChgAmt));

                $scope.currentCapitalPlanning.weightedAverageChgAmtYear2 =
                    (parseFloat1($scope.currentCapitalPlanning.capTier1ChgAmt) *
                        parseFloat1($scope.currentCapitalPlanning.capTier1ChgYear2) +
                        parseFloat1($scope.currentCapitalPlanning.capTier2ChgAmt) *
                        parseFloat1($scope.currentCapitalPlanning.capTier2ChgYear2)) /
                    (parseFloat1($scope.currentCapitalPlanning.capTier1ChgAmt) + parseFloat1($scope.currentCapitalPlanning.capTier2ChgAmt));

                $scope.currentCapitalPlanning.weightedAverageChgAmtYear3 =
                    (parseFloat1($scope.currentCapitalPlanning.capTier1ChgAmt) *
                        parseFloat1($scope.currentCapitalPlanning.capTier1ChgYear3) +
                        parseFloat1($scope.currentCapitalPlanning.capTier2ChgAmt) *
                        parseFloat1($scope.currentCapitalPlanning.capTier2ChgYear3)) /
                    (parseFloat1($scope.currentCapitalPlanning.capTier1ChgAmt) + parseFloat1($scope.currentCapitalPlanning.capTier2ChgAmt));

                $scope.currentCapitalPlanning.weightedAverageChgAmtYear1Disp = ppf($scope.currentCapitalPlanning.weightedAverageChgAmtYear1);
                $scope.currentCapitalPlanning.weightedAverageChgAmtYear2Disp = ppf($scope.currentCapitalPlanning.weightedAverageChgAmtYear2);
                $scope.currentCapitalPlanning.weightedAverageChgAmtYear3Disp = ppf($scope.currentCapitalPlanning.weightedAverageChgAmtYear3);

                $scope.currentCapitalPlanning.capTotalChgAmtDisp = mf(parseFloat1($scope.currentCapitalPlanning.capTier1ChgAmt) +
                    parseFloat1($scope.currentCapitalPlanning.capTier2ChgAmt));

                $scope.currentCapitalPlanning.capTier1AbsChgDisp = mf($scope.currentCapitalPlanning.capTier1AbsChg);
                $scope.currentCapitalPlanning.capTier2AbsChgDisp = mf($scope.currentCapitalPlanning.capTier2AbsChg);

                $scope.currentCapitalPlanning.capTier1BaseDisp = mf($scope.currentCapitalPlanning.capTier1Base);
                $scope.currentCapitalPlanning.capTier2BaseDisp = mf($scope.currentCapitalPlanning.capTier2Base);
                $scope.currentCapitalPlanning.capTotalBaseDisp = mf($scope.currentCapitalPlanning.capTotalBase);

                $scope.currentCapitalPlanning.capTier1ChgYear1Disp = ppf($scope.currentCapitalPlanning.capTier1ChgYear1);
                $scope.currentCapitalPlanning.capTier2ChgYear1Disp = ppf($scope.currentCapitalPlanning.capTier2ChgYear1);
                $scope.currentCapitalPlanning.capTier1ChgYear2Disp = ppf($scope.currentCapitalPlanning.capTier1ChgYear2);
                $scope.currentCapitalPlanning.capTier2ChgYear2Disp = ppf($scope.currentCapitalPlanning.capTier2ChgYear2);
                $scope.currentCapitalPlanning.capTier1ChgYear3Disp = ppf($scope.currentCapitalPlanning.capTier1ChgYear3);
                $scope.currentCapitalPlanning.capTier2ChgYear3Disp = ppf($scope.currentCapitalPlanning.capTier2ChgYear3);


                $scope.currentCapitalPlanning.capTotalChgYear1Disp = ppf($scope.currentCapitalPlanning.capTotalChgYear1);
                $scope.currentCapitalPlanning.capTotalChgYear2Disp = ppf($scope.currentCapitalPlanning.capTotalChgYear2);
                $scope.currentCapitalPlanning.capTotalChgYear3Disp = ppf($scope.currentCapitalPlanning.capTotalChgYear3);



                $scope.currentCapitalPlanning.capTier1SenDisp = mf($scope.currentCapitalPlanning.capTier1Sen);
                $scope.currentCapitalPlanning.capTier2SenDisp = mf($scope.currentCapitalPlanning.capTier2Sen);
                $scope.currentCapitalPlanning.capTotalSenDisp = mf($scope.currentCapitalPlanning.capTotalSen);

                $scope.rwaTotal = {
                    rwaBase: 0,
                    rwaChg: 0,
                    rwaChgYear1: 0,
                    rwaChgYear2: 0,
                    rwaChgYear3: 0,
                    eadSen: 0,
                    rwSen: 0,
                    rwaSen: 0,

                    sumRwaChgRwaChgYear1: 0,
                    sumRwaChgRwaChgYear2: 0,
                    sumRwaChgRwaChgYear3: 0,
                };

                var params = {
                    cpScenarioId: key.cpScenarioId,
                    snapshotDate: key.snapShotDate,
                    loadJobNbr: key.loadJobNbr,
                    scenarioId: key.scenarioId
                };
                CapitalPlanningService.getAllRwa(params).then(function (value) {
                    $scope.assetClassArr = _.map(assetClass, function (ac) {
                        var ass = _.find(value, function (v) {
                            return v.capRwaKey.assetClass === ac;
                        });

                        if (ass) {
                            ass.eadBaseDisp = mf(ass.eadBase);
                            ass.rwaBaseDisp = mf(ass.rwaBase);
                            ass.eadAbsChgDisp = mf(ass.eadAbsChg);
                            ass.rwaChgDisp = mf(ass.rwaChg);
                            ass.eadSenDisp = mf(ass.eadSen);
                            ass.rwaSenDisp = mf(ass.rwaSen);

                            ass.eadPctChgDisp = ppf(ass.eadPctChg);
                            ass.rwPctChgDisp = ppf(ass.rwPctChg);
                            ass.rwAbsChgDisp = ppf(ass.rwAbsChg);

                            ass.rwBaseDisp = pf(ass.rwBase);
                            ass.rwSenDisp = pf(ass.rwSen);

                            ass.rwaChgYear1Disp = ppf(ass.rwaChgYear1);
                            ass.rwaChgYear2Disp = ppf(ass.rwaChgYear2);
                            ass.rwaChgYear3Disp = ppf(ass.rwaChgYear3);

                            return ass;
                        } else {
                            return {
                                capRwaKey: {
                                    assetClass: ac,
                                    cpScenarioId: key.cpScenarioId,
                                    snapshotDate: key.snapShotDate,
                                    loadJobNbr: key.loadJobNbr,
                                    scenarioId: key.scenarioId
                                }
                            };
                        }
                    });

                    _.forEach($scope.assetClassArr, function (ass) {
                        $scope.rwaTotal.rwaBase += parseFloat1(ass.rwaBase);
                        $scope.rwaTotal.rwaChg += parseFloat1(ass.rwaChg);
                        $scope.rwaTotal.rwaChgYear1 += parseFloat1(ass.rwaChgYear1);
                        $scope.rwaTotal.rwaChgYear2 += parseFloat1(ass.rwaChgYear2);
                        $scope.rwaTotal.rwaChgYear3 += parseFloat1(ass.rwaChgYear3);
                        $scope.rwaTotal.eadSen += parseFloat1(ass.eadSen);
                        $scope.rwaTotal.rwaSen += parseFloat1(ass.rwaSen);

                        $scope.rwaTotal.sumRwaChgRwaChgYear1 += ppf(parseFloat1(ass.rwaChg) * parseFloat1(ass.rwaChgYear1));
                        $scope.rwaTotal.sumRwaChgRwaChgYear2 += ppf(parseFloat1(ass.rwaChg) * parseFloat1(ass.rwaChgYear2));
                        $scope.rwaTotal.sumRwaChgRwaChgYear3 += ppf(parseFloat1(ass.rwaChg) * parseFloat1(ass.rwaChgYear3));
                    });

                    $scope.rwaTotal.weightedAverageYear1 = _.round($scope.rwaTotal.sumRwaChgRwaChgYear1 / $scope.rwaTotal.rwaChg, 2);
                    $scope.rwaTotal.weightedAverageYear2 = _.round($scope.rwaTotal.sumRwaChgRwaChgYear2 / $scope.rwaTotal.rwaChg, 2);
                    $scope.rwaTotal.weightedAverageYear3 = _.round($scope.rwaTotal.sumRwaChgRwaChgYear3 / $scope.rwaTotal.rwaChg, 2);

                    $scope.rwaTotal.rwSen = $scope.rwaTotal.rwaSen / $scope.rwaTotal.eadSen;
                    $scope.rwaTotal.rwaBaseDisp = mf($scope.rwaTotal.rwaBase);
                    $scope.rwaTotal.rwaChgDisp = mf($scope.rwaTotal.rwaChg);

                    $scope.rwaTotal.rwaChgYear1Disp = ppf($scope.rwaTotal.rwaChgYear1);
                    $scope.rwaTotal.rwaChgYear2Disp = ppf($scope.rwaTotal.rwaChgYear2);
                    $scope.rwaTotal.rwaChgYear3Disp = ppf($scope.rwaTotal.rwaChgYear3);

                    $scope.rwaTotal.eadSenDisp = mf($scope.rwaTotal.eadSen);
                    $scope.rwaTotal.rwaSenDisp = mf($scope.rwaTotal.rwaSen);

                    $scope.rwaTotal.rwSenDisp = pf($scope.rwaTotal.rwSen);
                    $scope.rwaTotal.rwBaseDisp = pf($scope.rwaTotal.rwBase);

                    $scope.loading = false;
                    initChart();
                });



            };

            function getParamList() {
                CapitalPlanningService.getFields().then(function (value) {
                    $scope.Filter.filterOptions.snapshotDate = value.snapShotDate;
                    $scope.Filter.filterOptions.loadJobNbr = value.loadJobNbr;
                    $scope.Filter.filterOptions.scenarioId = value.scenarioId;
                    $scope.Filter.filterOptions.cpScenarioId = value.cpScenarioId;
                    $scope.Filter.filterOptions.interCompany = value.interCompany;
                });
            }

            var loadCapCapital = function() {
                CapitalPlanningService.getOne($scope.Filter.filterSelection).then(function (value) {
                    CapitalPlanningService.setCurrent(value);
                    mainFunc();
                });
            };

            $scope.resetFilter = function() {
                $scope.Filter.filterSelection = {};
                $scope.Filter.filterSelection.snapshotDate = '';
                $scope.Filter.filterSelection.loadJobNbr = '';
                $scope.Filter.filterSelection.scenarioId = '';
                $scope.Filter.filterSelection.cpScenarioId = '';
                $scope.Filter.filterSelection.interCompany = '';
            };

            getParamList();

            var carF = function (val) {
                var val1 = parseFloat(val);
                if (!isNaN(val1)){
                    return _.round(val1 * 100, 2)+'%';
                } else {
                    return '%';
                }
            }

            var initChart = function () {
                //-- CHART
                $scope.carTier1Base = carF($scope.currentCapitalPlanning.carTier1Base);
                $scope.carTotalBase = carF($scope.currentCapitalPlanning.carTotalBase);;
                $scope.carTier1Sen = carF($scope.currentCapitalPlanning.carTier1Sen);
                $scope.carTotalSen = carF($scope.currentCapitalPlanning.carTotalSen);

                var snapshotdtt = $scope.currentCapitalPlanning.capitalKey.snapShotDate.split('-');

                $scope.chartSnapshotDate = new Date(snapshotdtt[0], snapshotdtt[1], snapshotdtt[2]);
                $scope.chartYear1 = new Date(parseInt(snapshotdtt[0], 10) + 1, snapshotdtt[1], snapshotdtt[2]);
                $scope.chartYear2 = new Date(parseInt(snapshotdtt[0], 10) + 2, snapshotdtt[1], snapshotdtt[2]);
                $scope.chartYear3 = new Date(parseInt(snapshotdtt[0], 10) + 3, snapshotdtt[1], snapshotdtt[2]);


                $scope.capTotalChgYear1 = parseFloat($scope.currentCapitalPlanning.capTotalChgYear1);
                $scope.capTotalChgYear2 = parseFloat($scope.currentCapitalPlanning.capTotalChgYear2);
                $scope.capTotalChgYear3 = parseFloat($scope.currentCapitalPlanning.capTotalChgYear3);

                // for chart
                $scope.sumRwaSenYear1 = 0;
                $scope.sumRwaSenYear2 = 0;
                $scope.sumRwaSenYear3 = 0;

                for (var idx = 0; idx < $scope.assetClassArr.length; idx++) {
                    var rwaSen = parseFloat($scope.assetClassArr[idx].rwaSen);
                    var rwaChgYear1 = parseFloat($scope.assetClassArr[idx].rwaChgYear1);
                    var rwaChgYear2 = parseFloat($scope.assetClassArr[idx].rwaChgYear2);
                    var rwaChgYear3 = parseFloat($scope.assetClassArr[idx].rwaChgYear3);


                    if (!isNaN(rwaSen)) {
                        rwaChgYear1 = rwaChgYear1 || 0;
                        rwaChgYear2 = rwaChgYear2 || 0;
                        rwaChgYear3 = rwaChgYear3 || 0;

                        $scope.sumRwaSenYear1 += rwaSen * (1 + rwaChgYear1);
                        $scope.sumRwaSenYear2 += rwaSen * (1 + rwaChgYear1) * (1 + rwaChgYear2);
                        $scope.sumRwaSenYear3 += rwaSen * (1 + rwaChgYear1) * (1 + rwaChgYear2) * (1 + rwaChgYear3);
                    }
                }

                var carTotalBase = _.round(parseFloat($scope.currentCapitalPlanning.carTotalBase) * 100, 2);
                var carTotalSen = _.round(parseFloat($scope.currentCapitalPlanning.carTotalSen) * 100, 2);
                var capTotalSen = parseFloat($scope.currentCapitalPlanning.capTotalSen);
                var R1 = 100 * (capTotalSen * (1 + $scope.capTotalChgYear1))/$scope.sumRwaSenYear1;
                var R2 = 100 * (capTotalSen * (1 + $scope.capTotalChgYear1) * (1 + $scope.capTotalChgYear2)) / $scope.sumRwaSenYear2;
                var R3 = 100 * (capTotalSen * (1 + $scope.capTotalChgYear1) * (1 + $scope.capTotalChgYear2) * (1 + $scope.capTotalChgYear3))/$scope.sumRwaSenYear3;

                var chart = c3.generate({
                    bindto: '#capital-planing-chart',
                    padding: {
                        left: 50
                    },
                    data: {
                        columns: [
                            ['Baseline', carTotalBase, carTotalBase, carTotalBase, carTotalBase],
                            [
                                'Scenario',
                                carTotalSen,
                                R1,
                                R2,
                                R3
                            ]
                        ]
                    },
                    color: {
                        pattern: ['#aec7e8', '#ff7f0e', '#ffbb78', '#2ca02c', '#98df8a', '#d62728', '#ff9896', '#9467bd', '#c5b0d5', '#8c564b', '#c49c94', '#e377c2', '#f7b6d2', '#7f7f7f', '#c7c7c7', '#bcbd22', '#dbdb8d', '#17becf', '#9edae5']
                    },
                    axis: {
                        y: {
                            tick: {
                                count: 3,
                                format: function (d) {
                                    return _.round(d, 2) + '%'
                                }
                            }
                        },
                        x: {
                            type: 'category',
                            categories: [
                                dateF($scope.chartSnapshotDate, 'yyyy') + '(SnapShotDate)',
                                dateF($scope.chartYear1, 'yyyy'),
                                dateF($scope.chartYear2, 'yyyy'),
                                dateF($scope.chartYear3, 'yyyy')]
                        }
                    },
                    legend: {
                        position: 'right'
                    }
                });
            };

            if (!$scope.currentCapitalPlanning) {

                $scope.Filter.filterSelection.cpScenarioId = $routeParams.cpScenarioId;
                $scope.Filter.filterSelection.snapshotDate = $routeParams.snapshotDate;
                $scope.Filter.filterSelection.loadJobNbr = $routeParams.loadJobNbr;
                $scope.Filter.filterSelection.scenarioId = $routeParams.scenarioId;
                $scope.Filter.filterSelection.interCompany = $routeParams.interCompany;

                loadCapCapital();

            } else {
                mainFunc();
            }



            $scope.updateSnapshotDateState = function() {};
            $scope.updateLoadJobNbrState = function() {};
            $scope.updateScenarioIdState = function() {};
            $scope.updateCapitalScenarioState = function() {};
            $scope.updateInterCompanyState = function() {};

            $scope.dataChanged = function() {
                $scope.changing = true;
            };

            $scope.calculate = function() {
                $scope.loading = true;
                var capRwaList = _.compact(_.map($scope.assetClassArr, function (asset) {
                    return asset ? {
                        assetClass: asset.capRwaKey.assetClass,
                        eadPctChg: fpp(asset.eadPctChgDisp),
                        eadAbsChg: (parseFloat1(asset.eadAbsChgDisp) * 1000000),
                        rwPctChg: fpp(asset.rwPctChgDisp),
                        rwAbsChg: fpp(asset.rwAbsChgDisp),
                        rwaChg: fm(asset.rwaChgDisp),
                        rwaChgYear1: fpp(asset.rwaChgYear1Disp),
                        rwaChgYear2: fpp(asset.rwaChgYear2Disp),
                        rwaChgYear3: fpp(asset.rwaChgYear3Disp)
                    } : undefined;
                }));
                var params = {
                    cpScenarioId: $scope.Filter.filterSelection.cpScenarioId,
                    snapshotDate: $scope.Filter.filterSelection.snapshotDate || $scope.Filter.filterSelection.snapShotDate,
                    loadJobNbr: $scope.Filter.filterSelection.loadJobNbr,
                    scenarioId: $scope.Filter.filterSelection.scenarioId,
                    interCompany: $scope.Filter.filterSelection.interCompany,
                    //-- cap-capital-params
                    capTier1PctChg: fpp($scope.currentCapitalPlanning.capTier1PctChgDisp),
                    capTier1AbsChg: fm($scope.currentCapitalPlanning.capTier1AbsChgDisp),
                    capTier2PctChg: fpp($scope.currentCapitalPlanning.capTier2PctChgDisp),
                    capTier2AbsChg: fm($scope.currentCapitalPlanning.capTier2AbsChgDisp),
                    capTier1ChgYear1: fpp($scope.currentCapitalPlanning.capTier1ChgYear1Disp),
                    capTier2ChgYear1: fpp($scope.currentCapitalPlanning.capTier2ChgYear1Disp),
                    capTier1ChgYear2: fpp($scope.currentCapitalPlanning.capTier1ChgYear2Disp),
                    capTier2ChgYear2: fpp($scope.currentCapitalPlanning.capTier2ChgYear2Disp),
                    capTier1ChgYear3: fpp($scope.currentCapitalPlanning.capTier1ChgYear3Disp),
                    capTier2ChgYear3: fpp($scope.currentCapitalPlanning.capTier2ChgYear3Disp),
                    //-- cap-rwa-list
                    capRwaList: capRwaList

                };
                //console.log('Params', params);
                //console.log('$scope.Filter.filterSelection', $scope.Filter.filterSelection);
                CapitalPlanningService.callCapCalc(params).then(function (value) {
                    $scope.loading = false;
                    loadCapCapital();
                })
            };

            $scope.onBtnDoneClicked = function () {
                $location.path('capital-planning');
            }

        }
    ]);
