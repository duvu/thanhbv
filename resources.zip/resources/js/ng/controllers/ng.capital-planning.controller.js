angular.module('ng.capital-planning.controller', [])
    .controller('CapitalPlanningController', ['$scope', '$location', '_', 'CapitalPlanningService', 'VNotificationService', 'ConfirmService',
        function ($scope, $location, _, CapitalPlanningService, VNotificationService, ConfirmService) {

        $scope.capitalPlanningTable = {};
        $scope.Filter = {};
        $scope.RFilter = {};
        $scope.Filter.filterOptions = {};
        $scope.RFilter.filterOptions = {};
        $scope.loading = false;
        $scope.multi = false;

            function getCapitalList (params) {
                if (!params) {
                    params = {page: 0, size: 25, sort:'finishedAt,desc'};
                }
                $scope.loading = true;
                CapitalPlanningService.getAll(params).then(function (response) {
                    $scope.loading = false;
                    $scope.capitalPlanningTable.list = response.content;
                    $scope.capitalPlanningTable.totalPages = response.totalPages;
                    $scope.capitalPlanningTable.pageLength = response.size;
                    $scope.capitalPlanningTable.currentPage = response.number + 1;

                    $scope.capitalPlanningTable.totalElements = response.totalElements;
                });

            };

            function getParamList() {
                CapitalPlanningService.getFields().then(function (value) {
                    $scope.Filter.filterOptions.snapshotDate = value.snapShotDate.sort().reverse();
                    $scope.Filter.filterOptions.loadJobNbr = value.loadJobNbr.sort();
                    $scope.Filter.filterOptions.scenarioId = value.scenarioId.sort();
                    $scope.Filter.filterOptions.cpScenarioId = value.cpScenarioId.sort();
                    $scope.Filter.filterOptions.interCompany = value.interCompany.sort();
                });

                //$scope.loadRFields();
            }

            $scope.loadRFields = function () {
                $scope.loading = true;
                CapitalPlanningService.getRFields($scope.newCapitalPlanning).then(function (value) {
                    $scope.RFilter.filterOptions.snapshotDate = _.uniq(value.snapShotDate).sort().reverse();
                    $scope.RFilter.filterOptions.loadJobNbr = value.loadJobNbr.sort();
                    $scope.RFilter.filterOptions.scenarioId = value.scenarioId.sort();
                    $scope.RFilter.filterOptions.interCompany = value.interCompany.sort();
                    $scope.loading = false;
                })
            }

            $scope.resetFilter = function() {
                $scope.Filter.filterSelection = {};
                $scope.Filter.filterSelection.snapshotDate = '';
                $scope.Filter.filterSelection.loadJobNbr = '';
                $scope.Filter.filterSelection.scenarioId = '';
                $scope.Filter.filterSelection.cpScenarioId = '';
                $scope.Filter.filterSelection.interCompany = '';
            };

            $scope.resetFilter();
            getCapitalList({page: 0, size: 25, sort:''});
            getParamList();

            $scope.capitalPlanningTable.MasterCheckbox = function(masterCheck) {
                _.forEach($scope.capitalPlanningTable.list, function (row) {
                    row.$checked = masterCheck;
                });
            };

            $scope.capitalPlanningTable.delete = function() {
                $scope.loading = true;
                var delList = [];
                _.forEach($scope.capitalPlanningTable.list, function (row) {
                    if (row.$checked) {
                        delList.push(row.capitalKey);
                    }
                });

                CapitalPlanningService.delete(delList).then(function (value) {
                    getCapitalList();
                    getParamList()
                });
            };

            $scope.capitalPlanningTable.runCapLoad = function() {
                $scope.loading = true;
                var sels = getSelected();
                if (sels && sels.length === 1) {
                    $scope.loading = false;
                    goDetails(sels[0]);
                } else {
                    $scope.loading = false;
                }
            };

            var getSelected = function() {
                var sels = [];
                _.forEach($scope.capitalPlanningTable.list, function(data) {
                    if (data.$checked) {
                        sels.push(data)
                    }
                });
                return sels;
            };

            $scope.search = function() {
                var params = {
                    cpScenarioId: $scope.Filter.filterSelection.cpScenarioId,
                    snapShotDate: $scope.Filter.filterSelection.snapshotDate,
                    loadJobNbr: $scope.Filter.filterSelection.loadJobNbr,
                    scenarioId: $scope.Filter.filterSelection.scenarioId,
                    interCompany: $scope.Filter.filterSelection.interCompany,
                    page: 0,
                    size: 25,
                    sort:''
                };

                $scope.loading = true;
                CapitalPlanningService.search(params).then(function (value) {
                    $scope.loading = false;
                    $scope.capitalPlanningTable.list = response.content;
                    $scope.capitalPlanningTable.totalPages = response.totalPages;
                    $scope.capitalPlanningTable.pageLength = response.size;
                    $scope.capitalPlanningTable.currentPage = response.number + 1;

                    $scope.capitalPlanningTable.totalElements = response.totalElements;
                });
            };



            var goDetails = function (row) {
                CapitalPlanningService.setCurrent(row);
                var key = row.capitalKey;
                $location.path('capital-planning/' + key.cpScenarioId + '/' + key.snapShotDate + '/' + key.loadJobNbr + '/' + key.scenarioId + '/' + key.interCompany );
            }

            $scope.addNewCapitalPlanning = function () {
                //
                $scope.hideValidityStyle = true;
                $scope.newCapitalPlanning = {
                    interCompany: '',
                    snapshotDate: '',
                    loadJobNbr: '',
                    scenarioId: '',
                    cpScenarioId: ''
                };
                $scope.loadRFields();
                angular.element('#capitalPlanningModal').addClass('md-show');
            };

            $scope.closeCapitalPlanningModal = function () {
                angular.element('#capitalPlanningModal').removeClass('md-show');
            }

            $scope.saveCapitalPlanningModal = function () {
                $scope.loading = true;
                if (!$scope.newCapitalPlanningForm.$invalid) {
                    $scope.capitalPlanningTable.$saving = true;
                    CapitalPlanningService.create($scope.newCapitalPlanning).then(function (response) {
                        $scope.capitalPlanningTable.$saving = false;
                        $scope.closeCapitalPlanningModal();
                        getCapitalList();
                        getParamList();
                        setRunBtnsAvailability();

                    }, function (response) {
                        $scope.capitalPlanningTable.$saving = false;
                        ConfirmService.open(response.message, null, true);
                    });
                } else {
                    $scope.hideValidityStyle = false;
                    ConfirmService.open('Please fill in required fields.', null, true);
                }
            };
            
            function setRunBtnsAvailability() {
                //
            }
        }
    ]);
