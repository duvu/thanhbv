angular.module('ng.reports.controller', [])
    .controller('ReportsController', ['$scope', '$routeParams', '$http', '$sce', '$location',
        function ($scope, $routeParams, $http, $sce, $location) {

            $scope.showiframe = function (url) {
                if (!url) {
                    url = $scope.selectedUrl;
                }
                document.getElementById("iframeID").contentWindow.location.replace(url);
                $scope.reportDetailView = true;
            };
            

            // $scope.showiframe($scope.ibmcognosUrl);
            var serverUrl = 'http://10.1.14.68:8888';
            $scope.urls = [
                { label: 'SBV01 - Summary', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2001%20OS%20-%20Summary%20VN?rs:Embed=true' },
                { label: 'SBV03.2 - Capital Elements', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2003%20WR%20-%20Capital%20Information%20VN%202?rs:Embed=true' },
				{ label: 'SBV03 - Capital Elements', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2003%20WR%20-%20Capital%20Information%20VN?rs:Embed=true' },
                { label: 'SBV04 - Credit Risk - Sovereign', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2004%20WR%20-%20Credit%20Risk%20Weighted%20Assets%20-%20Sovereign%20Standardized%20VN?rs:Embed=true' },
                { label: 'SBV05 - Credit Risk - Financial Institutions', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2005%20WR%20-%20Credit%20Risk%20Weighted%20Assets%20-%20Bank%20Standardized%20VN?rs:Embed=true' },
                { label: 'SBV06 - Credit Risk - Coporate', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2006%20WR%20-%20Credit%20Risk%20Weighted%20Assets%20-%20Corporate%20-%20Standardized%20VN?rs:Embed=true' },
                { label: 'SBV07A - Credit Risk Retail', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2007A%20RR%20-%20Credit%20Risk%20Weighted%20Assets%20-%20Retail%20Standardized%20VN?rs:Embed=true' },
                { label: 'SBV07B - Credit Risk Real Estate', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2007B%20RR%20-%20Credit%20Risk%20Weighted%20Assets%20-%20Claims%20Secured%20by%20Real%20Estate%20Standardized%20VN?rs:Embed=true' },
                { label: 'SBV08 - Credit Risk Non Performing', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2008%20WR%20-%20Credit%20Risk%20Weighted%20Assets%20-%20Non%20Performing%20Standardized%20VN?rs:Embed=true' },
                { label: 'SBV09 - Credit Risk Other Exposures', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2009%20WR%20-%20Other%20Assets%20VN?rs:Embed=true' },
                { label: 'SBV10 - Operational Risk', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2010%20OR%20-%20Operational%20Risk%20VN?rs:Embed=true' },
                { label: 'SBV11 - Interest Rate Risk Specific', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2011%20MR%20-%20Market%20Risk%20-%20Specific%20Interest%20Rate%20Risk?rs:Embed=true' },
                { label: 'SBV12 - Interest Rate Risk General', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2012%20MR%20-%20Market%20Risk%20-%20General%20Interest%20Rate%20Risk?rs:Embed=true' },
                { label: 'SBV13 - Foreign Exchange Risk', link: serverUrl + '/Reports/report/Reports/ERA%20SBV%2013%20MR%20-%20Market%20Risk%20-%20Foreign%20Exchange%20Risk?rs:Embed=true' }
            ];

            //var urlReport = "http://23.100.91.142/Reports/report/RelulatoryReports/ERA%20SBV%2001%20WR%20-%20Summary?rs:Embed=true";
            $scope.selectedUrl = $scope.urls[0].link;
            $scope.showiframe($scope.selectedUrl);
        }]);
