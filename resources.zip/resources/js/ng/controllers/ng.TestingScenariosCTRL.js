angular.module('ng.TestingScenariosCTRL', [])
    .controller('TestingScenariosCTRL', [
    	function () {
    		console.log("ng.TestingScenariosCTRL " );

    		
    	}])