angular.module('ng.task-manager.controller', [])
    .controller('TaskManagerController', ['$scope', '$routeParams', '$location', '$filter', '_', 'TaskManagerService', 'VNotificationService', 'ConfirmService',
        function ($scope, $routeParams, $location, $filter, _, TaskManagerService, VNotificationService, ConfirmService) {
            $scope.taskManagerTable = {};

            function getTaskManagerList (params) {
                $scope.loading = true;
                if (!params) {
                    params = {page: 0, size: 25, sort: 'finishedAt,DESC'};
                }

                TaskManagerService.getTaskManagerList(params).then(function (response) {
                    console.log('value: ', response);
                    $scope.loading = false;
                    $scope.taskManagerTable.list = response.content;
                    $scope.taskManagerTable.totalPages = response.totalPages;
                    $scope.taskManagerTable.pageLength = response.size;
                    $scope.taskManagerTable.currentPage = response.number + 1;

                    $scope.taskManagerTable.totalElements = response.totalElements;
                })
            }

            getTaskManagerList({page: 0, size: 25, sort:'finishedAt,DESC'});

            $scope.cancelTaskManager = function (id) {
                $scope.loading = true;
                TaskManagerService.cancelTaskManager(id).then(function (value) {
                    console.log('OK!');
                    getTaskManagerList();
                });
            }
        }]);
