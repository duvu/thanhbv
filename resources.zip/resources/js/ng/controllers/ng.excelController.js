angular.module('ng.imf-main.controller', [])
    .controller('ImfMainController', ['$scope',
        function ($scope) {
            console.log("ImfMain_CTRL ");

        }]);
